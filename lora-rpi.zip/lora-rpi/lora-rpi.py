#!/usr/bin/env python3
"""
CubeSat LoRa Communication System
Raspberry Pi 4 with dual SX126X LoRa modules
"""

import time
import threading
import json
import RPi.GPIO as GPIO
import spidev
from datetime import datetime
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class SX126X:
    """SX126X LoRa Module Driver"""
    
    # Register addresses
    REG_LR_SYNCWORD = 0x0740
    REG_LR_PAYLOADLENGTH = 0x0702
    
    def __init__(self, spi_bus, spi_device, cs_pin, rst_pin, dio1_pin, busy_pin):
        self.spi_bus = spi_bus
        self.spi_device = spi_device
        self.cs_pin = cs_pin
        self.rst_pin = rst_pin
        self.dio1_pin = dio1_pin
        self.busy_pin = busy_pin
        
        # Initialize SPI
        self.spi = spidev.SpiDev()
        self.spi.open(spi_bus, spi_device)
        self.spi.max_speed_hz = 1000000
        self.spi.mode = 0
        
        # Initialize GPIO
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.cs_pin, GPIO.OUT)
        GPIO.setup(self.rst_pin, GPIO.OUT)
        GPIO.setup(self.dio1_pin, GPIO.IN)
        GPIO.setup(self.busy_pin, GPIO.IN)
        
        GPIO.output(self.cs_pin, GPIO.HIGH)
        GPIO.output(self.rst_pin, GPIO.HIGH)
        
        self.reset()
        self.init_module()
    
    def reset(self):
        """Reset the module"""
        GPIO.output(self.rst_pin, GPIO.LOW)
        time.sleep(0.01)
        GPIO.output(self.rst_pin, GPIO.HIGH)
        time.sleep(0.01)
        self.wait_not_busy()
    
    def wait_not_busy(self):
        """Wait until module is not busy"""
        timeout = 1000
        while GPIO.input(self.busy_pin) and timeout > 0:
            time.sleep(0.001)
            timeout -= 1
        if timeout == 0:
            logger.warning("Timeout waiting for module to be ready")
    
    def write_command(self, command, data=None):
        """Write command to module"""
        self.wait_not_busy()
        GPIO.output(self.cs_pin, GPIO.LOW)
        
        if data is None:
            self.spi.xfer2([command])
        else:
            self.spi.xfer2([command] + list(data))
        
        GPIO.output(self.cs_pin, GPIO.HIGH)
        self.wait_not_busy()
    
    def read_command(self, command, length):
        """Read command from module"""
        self.wait_not_busy()
        GPIO.output(self.cs_pin, GPIO.LOW)
        
        result = self.spi.xfer2([command] + [0x00] * length)
        
        GPIO.output(self.cs_pin, GPIO.HIGH)
        return result[1:]  # Skip command byte
    
    def init_module(self):
        """Initialize the LoRa module"""
        # Set standby mode
        self.write_command(0x80, [0x00])
        time.sleep(0.01)
        
        # Set packet type to LoRa
        self.write_command(0x8A, [0x01])
        
        # Set RF frequency (433 MHz)
        freq_reg = int(433000000 * (2**25) / 32000000)
        self.write_command(0x86, [
            (freq_reg >> 24) & 0xFF,
            (freq_reg >> 16) & 0xFF,
            (freq_reg >> 8) & 0xFF,
            freq_reg & 0xFF
        ])
        
        # Set modulation parameters (SF7, BW125, CR4/5)
        self.write_command(0x8B, [
            0x07,  # SF7
            0x04,  # BW125
            0x01,  # CR4/5
            0x00   # LowDataRateOptimize off
        ])
        
        # Set packet parameters
        self.write_command(0x8C, [
            0x00, 0x08,  # Preamble length (8)
            0x00,        # Header type (explicit)
            0xFF,        # Payload length (will be set per packet)
            0x01,        # CRC on
            0x00         # IQ standard
        ])
        
        # Set TX power (14 dBm)
        self.write_command(0x8E, [0x0E, 0x00])
        
        logger.info(f"SX126X initialized on CS pin {self.cs_pin}")
    
    def send_packet(self, data):
        """Send a packet"""
        if isinstance(data, str):
            data = data.encode('utf-8')
        
        # Set payload length
        self.write_command(0x8C, [
            0x00, 0x08,  # Preamble length
            0x00,        # Header type
            len(data),   # Payload length
            0x01,        # CRC on
            0x00         # IQ standard
        ])
        
        # Write payload to buffer
        self.write_command(0x0E, [0x00] + list(data))
        
        # Set TX mode
        self.write_command(0x83, [0x00, 0x00, 0x00])  # No timeout
        
        # Wait for TX done
        start_time = time.time()
        while not GPIO.input(self.dio1_pin) and (time.time() - start_time) < 5:
            time.sleep(0.01)
        
        # Clear IRQ
        self.write_command(0x02, [0xFF, 0xFF])
        
        logger.info(f"Sent packet: {data}")
    
    def receive_packet(self, timeout=5):
        """Receive a packet"""
        # Set RX mode
        self.write_command(0x82, [0x00, 0x00, 0x00])  # No timeout
        
        start_time = time.time()
        while not GPIO.input(self.dio1_pin) and (time.time() - start_time) < timeout:
            time.sleep(0.01)
        
        if GPIO.input(self.dio1_pin):
            # Get packet status
            status = self.read_command(0x14, 3)
            payload_length = status[0]
            
            if payload_length > 0:
                # Read packet data
                data = self.read_command(0x1E, payload_length)
                
                # Clear IRQ
                self.write_command(0x02, [0xFF, 0xFF])
                
                logger.info(f"Received packet: {bytes(data)}")
                return bytes(data)
        
        # Clear IRQ and return None if no packet received
        self.write_command(0x02, [0xFF, 0xFF])
        return None
    
    def get_rssi(self):
        """Get RSSI value"""
        status = self.read_command(0x17, 2)
        rssi = -status[0] / 2
        return rssi


class GroundStation:
    """Ground Station implementation"""
    
    def __init__(self, lora_module):
        self.lora = lora_module
        self.running = False
        self.telemetry_data = {}
        
    def start(self):
        """Start ground station operations"""
        self.running = True
        logger.info("Ground Station started")
        
        # Start command thread
        command_thread = threading.Thread(target=self.command_loop)
        command_thread.daemon = True
        command_thread.start()
        
        # Start telemetry listener
        self.listen_for_telemetry()
    
    def stop(self):
        """Stop ground station operations"""
        self.running = False
        logger.info("Ground Station stopped")
    
    def send_command(self, command):
        """Send command to CubeSat"""
        packet = {
            'type': 'COMMAND',
            'from': 'GROUND',
            'to': 'CUBESAT',
            'timestamp': datetime.now().isoformat(),
            'command': command
        }
        self.lora.send_packet(json.dumps(packet))
    
    def listen_for_telemetry(self):
        """Listen for telemetry from CubeSat"""
        while self.running:
            try:
                data = self.lora.receive_packet(timeout=2)
                if data:
                    try:
                        packet = json.loads(data.decode('utf-8'))
                        if packet.get('type') == 'TELEMETRY':
                            self.process_telemetry(packet)
                        elif packet.get('type') == 'BEACON':
                            self.process_beacon(packet)
                    except json.JSONDecodeError:
                        logger.warning(f"Invalid JSON received: {data}")
            except Exception as e:
                logger.error(f"Error in telemetry listener: {e}")
                time.sleep(1)
    
    def process_telemetry(self, packet):
        """Process received telemetry"""
        self.telemetry_data = packet.get('data', {})
        rssi = self.lora.get_rssi()
        logger.info(f"Telemetry received (RSSI: {rssi} dBm): {self.telemetry_data}")
    
    def process_beacon(self, packet):
        """Process received beacon"""
        rssi = self.lora.get_rssi()
        logger.info(f"Beacon received (RSSI: {rssi} dBm): {packet.get('data', {})}")
    
    def command_loop(self):
        """Interactive command loop"""
        commands = {
            '1': 'REQUEST_TELEMETRY',
            '2': 'HEALTH_CHECK',
            '3': 'START_BEACON',
            '4': 'STOP_BEACON',
            '5': 'RESET_SUBSYSTEM'
        }
        
        while self.running:
            try:
                print("\n=== Ground Station Commands ===")
                for key, cmd in commands.items():
                    print(f"{key}: {cmd}")
                print("q: Quit")
                
                choice = input("Enter command: ").strip()
                
                if choice == 'q':
                    self.stop()
                    break
                elif choice in commands:
                    self.send_command(commands[choice])
                else:
                    print("Invalid command")
                    
                time.sleep(0.1)
            except KeyboardInterrupt:
                self.stop()
                break


class CubeSat:
    """CubeSat implementation"""
    
    def __init__(self, lora_module):
        self.lora = lora_module
        self.running = False
        self.beacon_enabled = False
        self.telemetry_data = {
            'battery_voltage': 7.4,
            'battery_current': 0.5,
            'temperature': 25.0,
            'altitude': 450000,
            'status': 'NOMINAL',
            'uptime': 0
        }
        self.start_time = time.time()
    
    def start(self):
        """Start CubeSat operations"""
        self.running = True
        logger.info("CubeSat started")
        
        # Start command listener
        command_thread = threading.Thread(target=self.listen_for_commands)
        command_thread.daemon = True
        command_thread.start()
        
        # Start beacon thread
        beacon_thread = threading.Thread(target=self.beacon_loop)
        beacon_thread.daemon = True
        beacon_thread.start()
        
        # Start telemetry update thread
        telemetry_thread = threading.Thread(target=self.update_telemetry)
        telemetry_thread.daemon = True
        telemetry_thread.start()
    
    def stop(self):
        """Stop CubeSat operations"""
        self.running = False
        logger.info("CubeSat stopped")
    
    def listen_for_commands(self):
        """Listen for commands from Ground Station"""
        while self.running:
            try:
                data = self.lora.receive_packet(timeout=2)
                if data:
                    try:
                        packet = json.loads(data.decode('utf-8'))
                        if packet.get('type') == 'COMMAND' and packet.get('to') == 'CUBESAT':
                            self.process_command(packet)
                    except json.JSONDecodeError:
                        logger.warning(f"Invalid JSON received: {data}")
            except Exception as e:
                logger.error(f"Error in command listener: {e}")
                time.sleep(1)
    
    def process_command(self, packet):
        """Process received command"""
        command = packet.get('command')
        logger.info(f"Command received: {command}")
        
        if command == 'REQUEST_TELEMETRY':
            self.send_telemetry()
        elif command == 'HEALTH_CHECK':
            self.send_health_status()
        elif command == 'START_BEACON':
            self.beacon_enabled = True
            logger.info("Beacon enabled")
        elif command == 'STOP_BEACON':
            self.beacon_enabled = False
            logger.info("Beacon disabled")
        elif command == 'RESET_SUBSYSTEM':
            logger.info("Subsystem reset command received")
            # Simulate subsystem reset
            time.sleep(2)
            self.send_ack("RESET_COMPLETE")
    
    def send_telemetry(self):
        """Send telemetry data"""
        packet = {
            'type': 'TELEMETRY',
            'from': 'CUBESAT',
            'to': 'GROUND',
            'timestamp': datetime.now().isoformat(),
            'data': self.telemetry_data
        }
        self.lora.send_packet(json.dumps(packet))
    
    def send_health_status(self):
        """Send health status"""
        health_data = {
            'status': self.telemetry_data['status'],
            'uptime': self.telemetry_data['uptime'],
            'temperature': self.telemetry_data['temperature'],
            'battery_voltage': self.telemetry_data['battery_voltage']
        }
        
        packet = {
            'type': 'HEALTH',
            'from': 'CUBESAT',
            'to': 'GROUND',
            'timestamp': datetime.now().isoformat(),
            'data': health_data
        }
        self.lora.send_packet(json.dumps(packet))
    
    def send_ack(self, message):
        """Send acknowledgment"""
        packet = {
            'type': 'ACK',
            'from': 'CUBESAT',
            'to': 'GROUND',
            'timestamp': datetime.now().isoformat(),
            'message': message
        }
        self.lora.send_packet(json.dumps(packet))
    
    def beacon_loop(self):
        """Send periodic beacons"""
        while self.running:
            if self.beacon_enabled:
                beacon_data = {
                    'satellite_id': 'CUBESAT-01',
                    'timestamp': datetime.now().isoformat(),
                    'status': self.telemetry_data['status'],
                    'battery': self.telemetry_data['battery_voltage']
                }
                
                packet = {
                    'type': 'BEACON',
                    'from': 'CUBESAT',
                    'to': 'GROUND',
                    'timestamp': datetime.now().isoformat(),
                    'data': beacon_data
                }
                
                self.lora.send_packet(json.dumps(packet))
                logger.info("Beacon sent")
            
            time.sleep(30)  # Send beacon every 30 seconds
    
    def update_telemetry(self):
        """Update telemetry data"""
        while self.running:
            # Simulate changing telemetry
            self.telemetry_data['uptime'] = int(time.time() - self.start_time)
            self.telemetry_data['temperature'] = 25.0 + (time.time() % 10 - 5)  # Simulate temperature variation
            self.telemetry_data['battery_voltage'] = 7.4 - (time.time() % 100) * 0.001  # Simulate battery drain
            
            time.sleep(5)  # Update every 5 seconds


def main():
    """Main function to run the test"""
    print("CubeSat LoRa Communication Test")
    print("1: Run as Ground Station")
    print("2: Run as CubeSat")
    print("3: Run both (testing mode)")
    
    choice = input("Enter choice: ").strip()
    
    try:
        if choice == '1':
            # Ground Station mode
            lora = SX126X(
                spi_bus=0, spi_device=0,
                cs_pin=8, rst_pin=17, dio1_pin=27, busy_pin=22
            )
            gs = GroundStation(lora)
            gs.start()
            
        elif choice == '2':
            # CubeSat mode
            lora = SX126X(
                spi_bus=0, spi_device=1,
                cs_pin=7, rst_pin=23, dio1_pin=24, busy_pin=25
            )
            cubesat = CubeSat(lora)
            cubesat.start()
            
            # Keep running
            try:
                while cubesat.running:
                    time.sleep(1)
            except KeyboardInterrupt:
                cubesat.stop()
                
        elif choice == '3':
            # Both modes (testing)
            print("Testing mode - switching between Ground Station and CubeSat")
            
            # Initialize both modules
            lora_gs = SX126X(
                spi_bus=0, spi_device=0,
                cs_pin=8, rst_pin=17, dio1_pin=27, busy_pin=22
            )
            
            lora_sat = SX126X(
                spi_bus=0, spi_device=1,
                cs_pin=7, rst_pin=23, dio1_pin=24, busy_pin=25
            )
            
            # Start CubeSat
            cubesat = CubeSat(lora_sat)
            cubesat.start()
            
            time.sleep(2)  # Let CubeSat initialize
            
            # Start Ground Station
            gs = GroundStation(lora_gs)
            gs.start()
            
        else:
            print("Invalid choice")
            
    except KeyboardInterrupt:
        print("\nShutting down...")
    except Exception as e:
        logger.error(f"Error: {e}")
    finally:
        GPIO.cleanup()


if __name__ == "__main__":
    main()