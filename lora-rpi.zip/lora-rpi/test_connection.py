#!/usr/bin/env python3
"""Test GPIO connections"""
import RPi.GPIO as GPIO
import time

def test_gpio_pins():
    GPIO.setmode(GPIO.BCM)
    
    # Test pins for Module A1
    pins_a1 = {'RST': 17, 'DIO1': 27, 'BUSY': 22, 'CS': 8}
    # Test pins for Module B2  
    pins_b2 = {'RST': 23, 'DIO1': 24, 'BUSY': 25, 'CS': 7}
    
    print("Testing Module A1 connections...")
    for name, pin in pins_a1.items():
        GPIO.setup(pin, GPIO.OUT)
        GPIO.output(pin, GPIO.HIGH)
        time.sleep(0.1)
        GPIO.output(pin, GPIO.LOW)
        print(f"  {name} (GPIO {pin}): OK")
    
    print("Testing Module B2 connections...")
    for name, pin in pins_b2.items():
        GPIO.setup(pin, GPIO.OUT)
        GPIO.output(pin, GPIO.HIGH)
        time.sleep(0.1)
        GPIO.output(pin, GPIO.LOW)
        print(f"  {name} (GPIO {pin}): OK")
    
    GPIO.cleanup()
    print("All connections tested!")

if __name__ == "__main__":
    test_gpio_pins()