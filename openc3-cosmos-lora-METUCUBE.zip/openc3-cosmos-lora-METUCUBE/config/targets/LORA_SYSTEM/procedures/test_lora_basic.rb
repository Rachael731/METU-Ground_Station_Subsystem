# test_lora_basic.rb - Basic LoRa Communication Test
puts "Starting LoRa Basic Communication Test..."

# Test 1: Basic Ping Test
puts "Test 1: Basic Ping Test"
sequence = 1
cmd("LORA_SYSTEM PING with SEQUENCE #{sequence}, TARGET_ID 1")
wait_check_packet("LORA_SYSTEM", "PING_RESPONSE", {"SEQUENCE" => sequence}, 10)
puts "✓ Ping test passed"

# Test 2: Status Request
puts "Test 2: Status Request Test"
sequence += 1
cmd("LORA_SYSTEM REQUEST_STATUS with SEQUENCE #{sequence}, TARGET_ID 1")
wait_check_packet("LORA_SYSTEM", "CUBESAT_STATUS", {"SEQUENCE" => sequence}, 15)
puts "✓ Status request test passed"

# Test 3: Multiple Pings with RSSI Monitoring
puts "Test 3: RSSI Performance Test"
rssi_values = []
(1..10).each do |i|
  sequence += 1
  cmd("LORA_SYSTEM PING with SEQUENCE #{sequence}, TARGET_ID 1")
  packet = wait_check_packet("LORA_SYSTEM", "PING_RESPONSE", {"SEQUENCE" => sequence}, 10)
  rssi = tlm("LORA_SYSTEM PING_RESPONSE RSSI")
  rssi_values << rssi
  puts "Ping #{i}: RSSI = #{rssi} dBm"
  wait(1)
end

avg_rssi = rssi_values.sum / rssi_values.length
puts "Average RSSI: #{avg_rssi} dBm"
puts "RSSI Range: #{rssi_values.min} to #{rssi_values.max} dBm"

puts "Basic communication test completed successfully!"