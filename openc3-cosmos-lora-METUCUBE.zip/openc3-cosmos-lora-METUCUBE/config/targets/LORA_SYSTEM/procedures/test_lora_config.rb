# test_lora_config.rb - LoRa Configuration Test
puts "Starting LoRa Configuration Test..."

# Test different LoRa configurations
configurations = [
  {name: "Long Range", freq: 915000000, sf: 12, bw: 7, power: 20},
  {name: "Balanced", freq: 915000000, sf: 9, bw: 7, power: 17},
  {name: "Fast", freq: 915000000, sf: 7, bw: 8, power: 14},
  {name: "Low Power", freq: 915000000, sf: 10, bw: 7, power: 10}
]

results = {}

configurations.each do |config|
  puts "\nTesting configuration: #{config[:name]}"
  puts "SF: #{config[:sf]}, BW: #{config[:bw]}, Power: #{config[:power]}dBm"
  
  # Configure LoRa parameters
  sequence = 2000 + configurations.index(config)
  cmd("LORA_SYSTEM LORA_CONFIG with SEQUENCE #{sequence}, FREQUENCY #{config[:freq]}, SPREADING_FACTOR #{config[:sf]}, BANDWIDTH #{config[:bw]}, TX_POWER #{config[:power]}")
  
  wait(3) # Allow time for reconfiguration
  
  # Test communication with this configuration
  test_packets = 10
  success_count = 0
  rssi_values = []
  time_values = []
  
  (1..test_packets).each do |i|
    test_sequence = sequence + i * 10
    start_time = Time.now
    
    begin
      cmd("LORA_SYSTEM PING with SEQUENCE #{test_sequence}, TARGET_ID 1")
      wait_check_packet("LORA_SYSTEM", "PING_RESPONSE", {"SEQUENCE" => test_sequence}, 8)
      
      end_time = Time.now
      response_time = ((end_time - start_time) * 1000).round(2)
      rssi = tlm("LORA_SYSTEM PING_RESPONSE RSSI")
      
      success_count += 1
      rssi_values << rssi
      time_values << response_time
      
      print "."
    rescue
      print "X"
    end
    
    wait(2)
  end
  
  # Calculate results for this configuration
  success_rate = (success_count.to_f / test_packets * 100).round(2)
  avg_rssi = rssi_values.empty? ? "N/A" : (rssi_values.sum / rssi_values.length).round(2)
  avg_time = time_values.empty? ? "N/A" : (time_values.sum / time_values.length).round(2)
  
  results[config[:name]] = {
    success_rate: success_rate,
    avg_rssi: avg_rssi,
    avg_time: avg_time,
    sf: config[:sf],
    bw: config[:bw],
    power: config[:power]
  }
  
  puts "\nSuccess Rate: #{success_rate}%"
  puts "Average RSSI: #{avg_rssi} dBm" unless avg_rssi == "N/A"
  puts "Average Response Time: #{avg_time} ms" unless avg_time == "N/A"
end

# Print configuration test results
puts "\n" + "="*80
puts "LORA CONFIGURATION TEST RESULTS"
puts "="*80
puts "Config     | SF | BW | Pwr | Success | Avg RSSI | Avg Time"
puts "-"*80

results.each do |name, data|
  printf "%-10s | %2d | %2d | %3d | %6s%% | %8s | %8s\n", 
         name, 
         data[:sf], 
         data[:bw], 
         data[:power],
         data[:success_rate],
         data[:avg_rssi] == "N/A" ? "N/A" : "#{data[:avg_rssi]}dBm",
         data[:avg_time] == "N/A" ? "N/A" : "#{data[:avg_time]}ms"
end

puts "Configuration test completed!"