# test_lora_range.rb - Range Testing Procedure
puts "Starting LoRa Range Test..."
puts "Move CubeSat module to different distances and press Enter to test each position"

test_distances = [1, 5, 10, 25, 50, 100, 200] # meters
results = {}

test_distances.each do |distance|
  puts "\n=== Testing at #{distance} meters ==="
  puts "Position the CubeSat module at #{distance}m and press Enter..."
  gets
  
  # Test multiple packets at this distance
  success_count = 0
  rssi_values = []
  packet_times = []
  
  (1..20).each do |packet_num|
    sequence = distance * 100 + packet_num
    start_time = Time.now
    
    begin
      cmd("LORA_SYSTEM PING with SEQUENCE #{sequence}, TARGET_ID 1")
      wait_check_packet("LORA_SYSTEM", "PING_RESPONSE", {"SEQUENCE" => sequence}, 5)
      
      end_time = Time.now
      packet_time = ((end_time - start_time) * 1000).round(2)
      rssi = tlm("LORA_SYSTEM PING_RESPONSE RSSI")
      
      success_count += 1
      rssi_values << rssi
      packet_times << packet_time
      
      print "."
      
    rescue Exception => e
      print "X"
    end
    
    wait(0.5)
  end
  
  # Calculate statistics
  success_rate = (success_count / 20.0 * 100).round(2)
  avg_rssi = rssi_values.empty? ? "N/A" : (rssi_values.sum / rssi_values.length).round(2)
  avg_time = packet_times.empty? ? "N/A" : (packet_times.sum / packet_times.length).round(2)
  
  results[distance] = {
    success_rate: success_rate,
    avg_rssi: avg_rssi,
    avg_time: avg_time,
    packets_sent: 20,
    packets_received: success_count
  }
  
  puts "\nDistance: #{distance}m"
  puts "Success Rate: #{success_rate}%"
  puts "Average RSSI: #{avg_rssi} dBm" unless avg_rssi == "N/A"
  puts "Average Response Time: #{avg_time} ms" unless avg_time == "N/A"
end

# Print final results
puts "\n" + "="*50
puts "RANGE TEST RESULTS SUMMARY"
puts "="*50
puts "Distance | Success Rate | Avg RSSI | Avg Time"
puts "-"*50

results.each do |distance, data|
  puts sprintf("%8dm | %11s%% | %8s | %8s", 
               distance, 
               data[:success_rate], 
               data[:avg_rssi] == "N/A" ? "N/A" : "#{data[:avg_rssi]}dBm",
               data[:avg_time] == "N/A" ? "N/A" : "#{data[:avg_time]}ms")
end

puts "Range test completed!"