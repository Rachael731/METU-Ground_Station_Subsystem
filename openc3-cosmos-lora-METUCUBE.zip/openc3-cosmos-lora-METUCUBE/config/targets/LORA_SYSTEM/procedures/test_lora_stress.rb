# test_lora_stress.rb - Stress Testing Procedure
puts "Starting LoRa Stress Test..."

# Test continuous communication for 30 minutes
start_time = Time.now
end_time = start_time + (30 * 60) # 30 minutes

sequence = 1000
total_sent = 0
total_received = 0
total_errors = 0

puts "Running stress test for 30 minutes..."
puts "Start time: #{start_time}"

while Time.now < end_time
  begin
    # Send ping every 5 seconds
    cmd("LORA_SYSTEM PING with SEQUENCE #{sequence}, TARGET_ID 1")
    total_sent += 1
    
    # Try to receive response
    begin
      wait_check_packet("LORA_SYSTEM", "PING_RESPONSE", {"SEQUENCE" => sequence}, 4)
      total_received += 1
      print "."
    rescue
      total_errors += 1
      print "X"
    end
    
    # Request status every 10th packet
    if sequence % 10 == 0
      begin
        cmd("LORA_SYSTEM REQUEST_STATUS with SEQUENCE #{sequence + 10000}, TARGET_ID 1")
        wait_check_packet("LORA_SYSTEM", "CUBESAT_STATUS", {"SEQUENCE" => sequence + 10000}, 4)
        print "S"
      rescue
        print "s"
      end
    end
    
    sequence += 1
    wait(5)
    
    # Print progress every 50 packets
    if total_sent % 50 == 0
      elapsed = Time.now - start_time
      remaining = end_time - Time.now
      puts "\nProgress: #{total_sent} sent, #{total_received} received, #{total_errors} errors"
      puts "Elapsed: #{elapsed.to_i}s, Remaining: #{remaining.to_i}s"
    end
    
  rescue Exception => e
    puts "\nUnexpected error: #{e.message}"
    total_errors += 1
  end
end

# Final statistics
total_time = Time.now - start_time
success_rate = (total_received.to_f / total_sent * 100).round(2)

puts "\n" + "="*50
puts "STRESS TEST RESULTS"
puts "="*50
puts "Test Duration: #{total_time.to_i} seconds"
puts "Total Packets Sent: #{total_sent}"
puts "Total Packets Received: #{total_received}"
puts "Total Errors: #{total_errors}"
puts "Success Rate: #{success_rate}%"
puts "Average Rate: #{(total_sent / total_time * 60).round(2)} packets/minute"

puts "Stress test completed!"
