# LoRa System Interface for OpenC3 COSMOS
# Handles communication with LoRa modules via serial interface

require 'openc3/interfaces/serial_interface'
require 'json'

module OpenC3
  class LoraSystemInterface < SerialInterface
    
    def initialize(port, baud_rate = 115200, parity = :NONE, stop_bits = 1, timeout = 10.0)
      super(port, baud_rate, parity, stop_bits, timeout, timeout)
      @packet_log_writer = System.packet_log_writer
      @sequence_counter = 0
      @pending_commands = {}
      @stats = {
        packets_sent: 0,
        packets_received: 0,
        packets_lost: 0,
        total_errors: 0
      }
      Logger.info("LoRa System Interface initialized on #{port}")
    end

    def connect
      super
      Logger.info("LoRa System Interface connected")
      
      # Send initial configuration
      configure_lora_module
      
      # Start statistics thread
      start_statistics_thread
    end

    def disconnect
      @statistics_thread&.kill
      super
      Logger.info("LoRa System Interface disconnected")
    end

    def write_interface(data, extra = nil)
      Logger.debug("Writing data to LoRa interface: #{data.unpack('H*').first}")
      
      # Parse the command packet
      begin
        cmd_packet = parse_command_packet(data)
        if cmd_packet
          # Convert to JSON format for LoRa module
          lora_command = format_lora_command(cmd_packet)
          
          # Send via serial
          super(lora_command.bytes, extra)
          
          # Update statistics
          @stats[:packets_sent] += 1
          
          # Store pending command for acknowledgment tracking
          @pending_commands[cmd_packet[:sequence]] = {
            command: cmd_packet[:command],
            timestamp: Time.now,
            retries: 0
          }
        end
      rescue => e
        Logger.error("Error writing to LoRa interface: #{e.message}")
        @stats[:total_errors] += 1
      end
    end

    def read_interface
      # Read from serial interface
      data, extra = super
      return nil, nil unless data
      
      begin
        # Parse received data
        received_str = data.pack('C*').strip
        Logger.debug("Received from LoRa: #{received_str}")
        
        # Try to parse as JSON
        if received_str.start_with?('{') && received_str.end_with?('}')
          lora_data = JSON.parse(received_str)
          
          # Convert to OpenC3 packet format
          packet_data = format_cosmos_packet(lora_data)
          
          if packet_data
            @stats[:packets_received] += 1
            
            # Remove from pending commands if this is an acknowledgment
            if lora_data['type'] == 'response' && lora_data['seq']
              @pending_commands.delete(lora_data['seq'])
            end
            
            return packet_data, extra
          end
        else
          # Handle non-JSON responses (status messages, errors, etc.)
          Logger.info("LoRa Module Status: #{received_str}")
        end
        
      rescue JSON::ParserError => e
        Logger.warn("Failed to parse LoRa response as JSON: #{e.message}")
        Logger.debug("Raw data: #{received_str}")
      rescue => e
        Logger.error("Error reading from LoRa interface: #{e.message}")
        @stats[:total_errors] += 1
      end
      
      return nil, nil
    end

    private

    def configure_lora_module
      # Send initial configuration to LoRa module
      config = {
        cmd: "CONFIG",
        freq: 915_000_000,
        sf: 7,
        bw: 125_000,
        power: 17,
        timestamp: Time.now.to_i
      }
      
      config_json = config.to_json + "\n"
      super(config_json.bytes)
      Logger.info("Sent initial LoRa configuration")
    end

    def parse_command_packet(data)
      return nil if data.length < 4
      
      # Extract packet header information
      # Assuming OpenC3 packet format: [SYNC][LENGTH][PACKET_ID][DATA...]
      packet_id = data[2]
      
      case packet_id
      when 0x01 # PING command
        {
          command: "PING",
          packet_id: packet_id,
          sequence: (data[3] << 8) | data[4],
          target_id: data[5]
        }
      when 0x02 # REQUEST_STATUS command  
        {
          command: "STATUS",
          packet_id: packet_id,
          sequence: (data[3] << 8) | data[4],
          target_id: data[5]
        }
      when 0x03 # SET_POWER_MODE command
        {
          command: "POWER",
          packet_id: packet_id,
          sequence: (data[3] << 8) | data[4],
          target_id: data[5],
          power_mode: data[6]
        }
      when 0x04 # START_DATA_COLLECTION command
        {
          command: "DATA",
          packet_id: packet_id,
          sequence: (data[3] << 8) | data[4],
          target_id: data[5],
          collection_rate: (data[6] << 8) | data[7]
        }
      when 0x05 # LORA_CONFIG command
        {
          command: "LORA_CONFIG",
          packet_id: packet_id,
          sequence: (data[3] << 8) | data[4],
          frequency: (data[5] << 24) | (data[6] << 16) | (data[7] << 8) | data[8],
          spreading_factor: data[9],
          bandwidth: data[10],
          tx_power: data[11]
        }
      else
        Logger.warn("Unknown command packet ID: 0x#{packet_id.to_s(16)}")
        nil
      end
    end

    def format_lora_command(cmd_packet)
      # Convert OpenC3 command to JSON format for LoRa module
      lora_cmd = {
        cmd: cmd_packet[:command],
        seq: cmd_packet[:sequence],
        target: cmd_packet[:target_id],
        timestamp: Time.now.to_i
      }
      
      # Add command-specific parameters
      case cmd_packet[:command]
      when "POWER"
        lora_cmd[:mode] = cmd_packet[:power_mode]
      when "DATA"
        lora_cmd[:rate] = cmd_packet[:collection_rate]
      when "LORA_CONFIG"
        lora_cmd[:freq] = cmd_packet[:frequency]
        lora_cmd[:sf] = cmd_packet[:spreading_factor]
        lora_cmd[:bw] = cmd_packet[:bandwidth]
        