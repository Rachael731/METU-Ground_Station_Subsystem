#!/usr/bin/env python3
"""
LoRa Bridge Microservice for COSMOS
Interfaces between COSMOS and LoRa modules for CubeSat communication
"""

import serial
import time
import json
import struct
import threading
import queue
import logging
from datetime import datetime
import socket
import sys
import argparse

class LoRaBridge:
    def __init__(self, serial_port='/dev/ttyUSB0', baud_rate=115200, cosmos_host='localhost', cosmos_port=7779):
        self.serial_port = serial_port
        self.baud_rate = baud_rate
        self.cosmos_host = cosmos_host
        self.cosmos_port = cosmos_port
        
        # Initialize serial connection
        self.ser = None
        self.cosmos_socket = None
        
        # Threading
        self.running = False
        self.rx_queue = queue.Queue()
        self.tx_queue = queue.Queue()
        
        # Setup logging
        logging.basicConfig(level=logging.INFO, 
                          format='%(asctime)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger(__name__)
        
        # LoRa configuration
        self.lora_config = {
            'frequency': 433000000,  # 433 MHz
            'bandwidth': 125000,     # 125 kHz
            'spreading_factor': 7,   # SF7
            'coding_rate': 5,        # 4/5
            'sync_word': 0x12,
            'power': 14              # 14 dBm
        }

    def connect_serial(self):
        """Connect to LoRa module via serial"""
        try:
            self.ser = serial.Serial(
                port=self.serial_port,
                baudrate=self.baud_rate,
                timeout=1,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE
            )
            self.logger.info(f"Connected to LoRa module on {self.serial_port}")
            return True
        except Exception as e:
            self.logger.error(f"Failed to connect to serial port: {e}")
            return False

    def connect_cosmos(self):
        """Connect to COSMOS interface"""
        try:
            self.cosmos_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.cosmos_socket.connect((self.cosmos_host, self.cosmos_port))
            self.logger.info(f"Connected to COSMOS at {self.cosmos_host}:{self.cosmos_port}")
            return True
        except Exception as e:
            self.logger.error(f"Failed to connect to COSMOS: {e}")
            return False

    def configure_lora(self):
        """Configure LoRa module parameters"""
        try:
            # Send configuration commands to LoRa module
            config_commands = [
                f"AT+BAND={self.lora_config['frequency']}",
                f"AT+PARAMETER={self.lora_config['spreading_factor']},{self.lora_config['bandwidth']},{self.lora_config['coding_rate']},{self.lora_config['power']}",
                f"AT+NETWORKID={self.lora_config['sync_word']}",
                "AT+MODE=0",  # Transparent mode
                "AT+IPR=115200"  # Baud rate
            ]
            
            for cmd in config_commands:
                self.send_at_command(cmd)
                time.sleep(0.1)
                
            self.logger.info("LoRa module configured successfully")
            return True
        except Exception as e:
            self.logger.error(f"Failed to configure LoRa module: {e}")
            return False

    def send_at_command(self, command):
        """Send AT command to LoRa module"""
        if self.ser:
            cmd = command + '\r\n'
            self.ser.write(cmd.encode())
            response = self.ser.readline().decode().strip()
            self.logger.debug(f"AT Command: {command} -> Response: {response}")
            return response
        return None

    def serial_reader_thread(self):
        """Thread to read data from LoRa module"""
        while self.running:
            try:
                if self.ser and self.ser.in_waiting > 0:
                    data = self.ser.readline()
                    if data:
                        # Process received LoRa data
                        self.process_received_data(data)
            except Exception as e:
                self.logger.error(f"Serial reader error: {e}")
            time.sleep(0.01)

    def serial_writer_thread(self):
        """Thread to write data to LoRa module"""
        while self.running:
            try:
                if not self.tx_queue.empty():
                    data = self.tx_queue.get(timeout=1)
                    if self.ser:
                        self.ser.write(data)
                        self.logger.debug(f"Sent to LoRa: {data}")
            except queue.Empty:
                continue
            except Exception as e:
                self.logger.error(f"Serial writer error: {e}")

    def cosmos_handler_thread(self):
        """Thread to handle COSMOS communication"""
        while self.running:
            try:
                if self.cosmos_socket:
                    # Receive commands from COSMOS
                    data = self.cosmos_socket.recv(1024)
                    if data:
                        self.process_cosmos_command(data)
            except Exception as e:
                self.logger.error(f"COSMOS handler error: {e}")
            time.sleep(0.01)

    def process_received_data(self, data):
        """Process data received from LoRa module"""
        try:
            # Parse LoRa packet
            if data.startswith(b'+RCV='):
                # Format: +RCV=<address>,<length>,<data>,<RSSI>,<SNR>
                parts = data.decode().strip().split(',')
                if len(parts) >= 5:
                    address = parts[0].split('=')[1]
                    length = int(parts[1])
                    payload = parts[2]
                    rssi = int(parts[3])
                    snr = float(parts[4])
                    
                    # Create COSMOS telemetry packet
                    tlm_packet = self.create_telemetry_packet(payload, rssi, snr)
                    
                    # Send to COSMOS
                    if self.cosmos_socket:
                        self.cosmos_socket.send(tlm_packet)
                        
                    self.logger.info(f"Received packet - RSSI: {rssi} dBm, SNR: {snr} dB")
                    
        except Exception as e:
            self.logger.error(f"Error processing received data: {e}")

    def process_cosmos_command(self, data):
        """Process command from COSMOS"""
        try:
            # Parse COSMOS command packet
            # This is a simplified parser - adjust based on your COSMOS packet format
            command_data = data.decode().strip()
            
            # Convert COSMOS command to LoRa transmission
            lora_packet = self.create_lora_packet(command_data)
            
            # Queue for transmission
            self.tx_queue.put(lora_packet)
            
            self.logger.info(f"Queued command for transmission: {command_data}")
            
        except Exception as e:
            self.logger.error(f"Error processing COSMOS command: {e}")

    def create_telemetry_packet(self, payload, rssi, snr):
        """Create COSMOS telemetry packet from LoRa data"""
        # COSMOS packet format (adjust as needed)
        packet = {
            'target': 'LORA_SYSTEM',
            'packet': 'TELEMETRY',
            'timestamp': datetime.now().isoformat(),
            'data': {
                'payload': payload,
                'rssi': rssi,
                'snr': snr,
                'frequency': self.lora_config['frequency']
            }
        }
        return json.dumps(packet).encode() + b'\n'

    def create_lora_packet(self, command):
        """Create LoRa packet from COSMOS command"""
        # Simple packet format - customize as needed
        packet = f"AT+SEND=1,{len(command)},{command}\r\n"
        return packet.encode()

    def start(self):
        """Start the LoRa bridge service"""
        self.logger.info("Starting LoRa Bridge Service...")
        
        # Connect to devices
        if not self.connect_serial():
            return False
            
        if not self.connect_cosmos():
            return False
            
        # Configure LoRa module
        if not self.configure_lora():
            return False
        
        # Start threads
        self.running = True
        
        self.serial_reader = threading.Thread(target=self.serial_reader_thread)
        self.serial_writer = threading.Thread(target=self.serial_writer_thread)
        self.cosmos_handler = threading.Thread(target=self.cosmos_handler_thread)
        
        self.serial_reader.start()
        self.serial_writer.start()
        self.cosmos_handler.start()
        
        self.logger.info("LoRa Bridge Service started successfully")
        return True

    def stop(self):
        """Stop the LoRa bridge service"""
        self.logger.info("Stopping LoRa Bridge Service...")
        
        self.running = False
        
        # Wait for threads to finish
        if hasattr(self, 'serial_reader'):
            self.serial_reader.join()
        if hasattr(self, 'serial_writer'):
            self.serial_writer.join()
        if hasattr(self, 'cosmos_handler'):
            self.cosmos_handler.join()
        
        # Close connections
        if self.ser:
            self.ser.close()
        if self.cosmos_socket:
            self.cosmos_socket.close()
            
        self.logger.info("LoRa Bridge Service stopped")

def main():
    parser = argparse.ArgumentParser(description='LoRa Bridge for COSMOS')
    parser.add_argument('--serial-port', default='/dev/ttyUSB0', help='Serial port for LoRa module')
    parser.add_argument('--baud-rate', type=int, default=115200, help='Serial baud rate')
    parser.add_argument('--cosmos-host', default='localhost', help='COSMOS host')
    parser.add_argument('--cosmos-port', type=int, default=7779, help='COSMOS port')
    
    args = parser.parse_args()
    
    bridge = LoRaBridge(
        serial_port=args.serial_port,
        baud_rate=args.baud_rate,
        cosmos_host=args.cosmos_host,
        cosmos_port=args.cosmos_port
    )
    
    try:
        if bridge.start():
            print("LoRa Bridge running... Press Ctrl+C to stop")
            while True:
                time.sleep(1)
    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        bridge.stop()

if __name__ == "__main__":
    main()